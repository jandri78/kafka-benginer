package tellafriend;

public class ReferalProgramContactInformation {

}
