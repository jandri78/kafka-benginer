package tellafriend;

public class TellAFriendConstants {

	public static final String AMOUNT = "fixed_amount";
	public static final String PERCENTAGE = "percentage";
}
