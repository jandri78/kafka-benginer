package tellafriend;

public class ReferalProgramAdvocateDTO {

}
