package tellafriend;

public class ReferalProgramStyle {

}
