package tellafriend;

public class ReferalProgramShareChannel {

}
