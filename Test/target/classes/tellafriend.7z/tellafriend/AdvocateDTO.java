package tellafriend;

public class AdvocateDTO {

}
