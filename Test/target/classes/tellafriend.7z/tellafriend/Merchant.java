package tellafriend;

public class Merchant {

}
